/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectakhir;

/**
 *
 * @author Praktikan
 */
public class BarangConnection {
    private final Connection CONN;
    
    public BarangConnection;
    

    
    }
    
}
