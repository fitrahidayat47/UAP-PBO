/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectakhir;

import db.DBHelper;
import java.sql.Connection;

/**
 *
 * @author Praktikan
 */
public class Projectakhir {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Connection connection = DBHelper.getConnection();
{
        Barang bg = new Barang ("p54321", "desember 2023", "keripik", 30000, 2, 2500,"makanan")
                BarangConnection bc = new BarangConnection();
                bc.addBarang(bc);
                bc.deleteBarang("p54321");
    }
    }
    
}
